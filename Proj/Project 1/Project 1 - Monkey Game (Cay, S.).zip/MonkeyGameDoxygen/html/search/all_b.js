var searchData=
[
  ['valid8',['valid8',['../main_8cpp.html#a01dbbbcd6513fbd975e5f9ce37867f33',1,'main.cpp']]],
  ['valid82',['valid82',['../main_8cpp.html#ad1ead62302f2ef1e295f2d8cda84ee77',1,'main.cpp']]]
];
