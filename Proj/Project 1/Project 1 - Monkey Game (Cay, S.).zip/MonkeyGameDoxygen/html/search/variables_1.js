var searchData=
[
  ['p1',['p1',['../struct_card.html#aa4091225d41dc493be8338c4bd7cd328',1,'Card']]],
  ['p2',['p2',['../struct_card.html#a74435284e52d8899c46c8dd159b0a763',1,'Card']]]
];
