var searchData=
[
  ['ply1lft',['ply1Lft',['../main_8cpp.html#a627c053336e8b3846242dbebf0c190cb',1,'main.cpp']]],
  ['ply2lft',['ply2Lft',['../main_8cpp.html#ac22b4a61f5dd4cb9c347a41aa6fbc8a2',1,'main.cpp']]],
  ['pntsfar',['pntSfar',['../main_8cpp.html#aa39832acaaec1e70f0e340d8052bc719',1,'main.cpp']]]
];
