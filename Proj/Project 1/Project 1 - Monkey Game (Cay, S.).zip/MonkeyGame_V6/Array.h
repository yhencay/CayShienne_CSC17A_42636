/* 
 * File:   Array.h
 * Author: ShiennePatricia
 *
 * Created on April 11, 2017, 2:08 PM
 */

#ifndef ARRAY_H
#define ARRAY_H

struct Card {
    string *cards;  //Set of cards
    string *p1;     //Player 1 Cards
    string *p2;     //Player 2 Cards
};

#endif /* ARRAY_H */

