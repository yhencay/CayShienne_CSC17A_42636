/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Points.h
 * Author: ShiennePatricia
 *
 * Created on June 2, 2017, 2:51 PM
 */

#ifndef POINTS_H
#define POINTS_H

class Pnts {        //Abstract Class inherited by Eliminate Class
public:
    virtual void points()=0;    //Pure virtual function
};

#endif /* POINTS_H */

