var searchData=
[
  ['p1',['p1',['../struct_card.html#aa4091225d41dc493be8338c4bd7cd328',1,'Card']]],
  ['p1name',['p1name',['../class_player.html#ad2826d370acd0b7aed1366ec176117ea',1,'Player']]],
  ['p2',['p2',['../struct_card.html#a74435284e52d8899c46c8dd159b0a763',1,'Card']]],
  ['p2name',['p2name',['../class_player.html#ad1768f6a8c7ac46c5669352dbb8c15df',1,'Player']]]
];
