var searchData=
[
  ['elimcrd',['elimCrd',['../class_elimin8.html#abd8e984300a14ff99cd1d4eb8ce63e45',1,'Elimin8']]],
  ['elimin8',['Elimin8',['../class_elimin8.html#a5ce69c2d18fc8961cde912fa26962d7e',1,'Elimin8::Elimin8()'],['../class_elimin8.html#a1820753414272a9dd1a3fb9c06aaca19',1,'Elimin8::Elimin8(short p1, short p2)']]]
];
