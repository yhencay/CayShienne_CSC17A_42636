var searchData=
[
  ['valid8',['valid8',['../class_elimin8.html#aac9b9fff952272117632a75b78cbac67',1,'Elimin8::valid8()'],['../class_player.html#aaf62eff23c4700aa5e47808a79bc8942',1,'Player::valid8()']]],
  ['valid82',['valid82',['../class_elimin8.html#af8afa45e9335b5dd2a269aa7b0cbdafd',1,'Elimin8']]]
];
