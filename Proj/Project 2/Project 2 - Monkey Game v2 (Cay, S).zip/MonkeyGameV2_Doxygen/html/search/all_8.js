var searchData=
[
  ['operator_2b_2b',['operator++',['../class_player.html#a792761d5ad36a51e2691126ab2bfee18',1,'Player']]]
];
