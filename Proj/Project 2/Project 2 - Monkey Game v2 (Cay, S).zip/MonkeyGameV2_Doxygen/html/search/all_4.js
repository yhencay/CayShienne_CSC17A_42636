var searchData=
[
  ['getlft1',['getLft1',['../class_player.html#acf047fd5302463a8bda70122eb061aca',1,'Player']]],
  ['getlft2',['getLft2',['../class_player.html#a9c6a62cfe4aa73846958d189a509c2ce',1,'Player']]],
  ['getnme1',['getNme1',['../class_player.html#a7d92db987d6061933c09f8d940cb9447',1,'Player']]],
  ['getnme2',['getNme2',['../class_player.html#a3cc2895065676cc313eb088f6667195c',1,'Player']]]
];
