var searchData=
[
  ['cards',['cards',['../struct_card.html#a3e3dcf05b4dd2dc5c0912068313701b2',1,'Card']]]
];
