var searchData=
[
  ['fildeck',['filDeck',['../class_player.html#a09fc71e3c23595a9a53bc065995e4842',1,'Player']]],
  ['filvec',['filVec',['../class_player.html#ad8e9de4744719612fbe5c92ffa1eb742',1,'Player']]]
];
