var searchData=
[
  ['player',['Player',['../class_player.html',1,'']]],
  ['pnts',['Pnts',['../class_pnts.html',1,'']]]
];
